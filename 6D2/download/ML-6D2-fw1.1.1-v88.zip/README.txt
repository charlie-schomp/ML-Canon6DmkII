Magic Lantern for the Canon EOS 6D Mark II - v88, firmware 1.1.1
Tested on a camera.

WHAT GOES ON THE CARD
    autoexec.bin
    ML  (the whole folder)
    ML-SETUP.FIR  (first install only)

Everything in "extras" stays on your computer.

FIRST INSTALL
    1. Format the card in the camera.
    2. Copy the files above to the root of the card.
    3. Canon menu > Wrench tab > Firmware > update from the card. This marks
       the card bootable; it does not change Canon's firmware.
    4. Restart the camera. The Trash button opens the Magic Lantern menu.
    5. Magic Lantern menu > Modules: turn on mlv_lite (raw video), restart.

UPDATING
    Replace autoexec.bin and the ML folder (keep ML/SETTINGS for your
    settings), then restart the camera.

MORE
    extras/user-guide.md   where everything is, card speeds, tips
    extras/tools           cardcheck.py checks the clips on a card
    https://github.com/charlie-schomp/ML-Canon6DmkII

Experimental software, no warranty. If the camera ever locks up, take the
battery out, and keep any CRASH*.LOG / ASSERT*.LOG from the card.
