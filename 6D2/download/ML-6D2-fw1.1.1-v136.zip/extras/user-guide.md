# User guide — Magic Lantern for the EOS 6D Mark II

Raw video and the full monitoring overlay set on a DIGIC 7 body.

    Firmware 1.1.1  — tested on a camera
    Firmware 1.2.0  — not supported in current releases

## Install

1. Format the card in the camera.
2. Copy `autoexec.bin`, the `ML` folder and `ML-SETUP.FIR` from the zip to the root of the card.
3. Canon menu → Wrench tab → Firmware → update from the card (this marks the card bootable; Canon's
   firmware is not changed), then restart. The **Trash** button opens Magic Lantern.

Updating: replace `autoexec.bin` and `ML/`, keep `ML/SETTINGS/`, and restart the camera — Magic
Lantern loads at power-on, so a new version does nothing until you do.

**Clearing a card:** Canon menu → **Format card** shows *Format card, keep ML* (INFO switches to
*remove ML*). After the format Magic Lantern copies itself back and asks you to turn the camera off
and on. Don't clear cards by deleting files on a Mac or PC: the computer leaves hidden files behind,
and a card cleared that way writes more slowly.

### Out of the box

A new card starts with: scratch audio **Auto with RAW**, **H.264 proxy on**, recorded-area frame
guides, false colour / waveform / zebras reading the **raw** data, the **AF** button toggling focus
peaking and **DRIVE / metering** toggling false colour, the audio **level meter** on while the WAV
records, spotmeter off, sync beep off. Change anything you like; updates keep your
changes.

## Where things are

| | |
|---|---|
| RAW video | Movie → RAW video, the first entry (enable the `mlv_lite` module first). **Data format** defaults to **12-bit lossless**. It also offers 14-bit lossless and uncompressed 14 / 12 / 10-bit |
| Changing bit depth | Pick it, then **close the ML menu**: the view zooms in and out once and the entry reads `live`. The setting is saved and applies itself the same way at power-on and on switching to movie mode. Needs the lens on **MF** (Canon refuses the zoom with the lens on AF); with AF, Canon's MENU and back applies it instead |
| Crop mode | Movie → RAW video → **Crop mode**, below Data format — holds Canon's 5x zoom: a 1:1 sensor window, up to 3072×896, always 29.97 fps. Lens on **MF**; switching the lens to MF (or closing the ML menu) brings it in |
| Video dual ISO | enable `dual_iso`, turn on Expo → Dual ISO, and use RAW video → **Crop mode**: only the 1:1 readout alternates the line pairs (the binned 1080p readout applies one gain), and crop mode is also where the higher resolutions are, up to 3072 wide. The **Recovery ISO** is the second ISO: for the most range, Canon ISO 100 and Recovery 800–1600. On this body the line pairs differ by less than the ISO gap — measured 1.7 EV at 100 / 800 — so the gain is real but smaller than the menu's estimate. MLV App: Dual ISO **On**, pattern low-low-HIGH-HIGH |
| Scratch audio | Movie → **Scratch audio**, one submenu: **Mode** OFF / Auto with RAW / Manual, **Record WAV now** (Manual mode only), **Input** Auto (jack) / Internal / External, **Level meter** OFF / While recording, **Gain** Factory / Manual with **Left gain** in 3 dB stops (Mute, −12 … +42 dB), **Right channel** Same as left / Own level / Safety −6 … −24 dB, **Right gain** |
| Gyro log | Movie → RAW video → **Gyro log (experimental)**: records the body's gyro inside each clip (about 24 KB/s), for stabilising in post. `python extras/tools/gyro_export.py <card>` writes a Gyroflow log per clip. Turn lens IS off for those shots. Being tested: see [gyro-test.md](gyro-test.md) |
| Focus peaking | Overlay → Focus Peak — **Edge density: Dots / Lines**, **Noise rejection: OFF / Steady / Steady + Wide** |
| Frame guides | Overlay → Cropmarks = **OFF / Recorded area** (shades outside what's recorded) + **Framing guide** inside it. Off in crop mode. Needs Overlay → **RAW preview** on Real-time (the default) or Auto: in Framing you see only a thin outline. Bitmap cropmarks are not in this build. |
| Resolution / aspect | Movie → RAW video. 1080p goes up to **2048** wide (2080 active columns), crop mode up to 3072; each keeps its own pick. Aspect **1.90:1 (DCI)** gives 2048×1080. **If aspect too tall** (RAW video's Advanced section) = Shrink width (default) keeps the ratio; Clamp height keeps the width |
| Flip screen | automatic — overlays follow Canon's image in all three screen positions |
| H.264 proxy | Movie → RAW video → **H.264 proxy**, under Crop mode (on by default). Records Canon's H.264 next to every raw clip on the same card, for smooth review in Canon's player: `IMG_1234.MLV` pairs with `MVI_1234.MP4`. Canon movie size **1080 IPB 23.98**. Costs ~3.6 MB/s |
| Top buttons | Movie → **Top Button C-FN**, all OFF by default — in movie LiveView, **AF**, **ISO** and **DRIVE / metering / AF-point** (one setting: the camera reports the three identically) each toggle an overlay of your choice. Canon's own screen still flashes up; ISO stays adjustable with the dial until its screen closes. **AF works at standby only** - during a take Canon reports it exactly like the rear dial - so put the overlay you need while rolling (peaking) on **DRIVE**. The light button can't be used: the rear dial sends the same signal |
| Audio level meter | Movie → Scratch audio → **Level meter** — two bars in dBFS at the top left of LiveView while the WAV records: **top = level, bottom = peak** (what the camera's audio hardware reports — it has no separate left/right reading), with a 1.5 s hold tick, the values (`lvl … pk …`), the mic in use (int / ext) and **CLIP** in red. Keep peaks below about −6 dBFS. Hidden whenever a Canon or ML menu is open |
| Shutter angle lock | Movie → **Shutter angle lock** OFF / 90 / 120 / 144 / **180** / 270 / 360° — keeps the shutter at that angle when the frame rate changes (1080p 23.976 ↔ crop mode 29.97, or a Canon movie size change): 180° is 1/50 at 23.976 (172.6°) and 1/60 at 29.97 (179.8°), the nearest speeds Canon offers. Needs Canon's movie exposure on **Manual**; never changes anything during a take; turning the shutter dial while it's on is undone |
| Clip info | Movie → **Clip info**, ON, then press **Q** for **Camera**, **Reel**, **Scene**, **Shot** and **Take**. Take counts up after each clip and goes back to 1 when the scene or shot changes. RAW takes carry the slate in the MLV, which MLV Drive and MLV App read. MP4-only takes add a line to `SLATE.CSV` beside the clips, ready for Resolve's Import Metadata |
| Sync beep | Movie → Scratch audio → **Sync beep** (off by default). Beeps when a RAW take starts, for sound recorded on another device. It lands in the scratch WAV and the proxy's audio |
| MP4 length | Movie → **MOV/MP4 time limit**, the last entry |
| RAW preview | Overlay → **RAW preview**: Auto / **Real-time** (default) / Framing / Frozen LV |
| Clean HDMI | Overlay → **Clean HDMI out** — no ML overlays or bars while HDMI is connected |
| Temperature | Debug → **Internal Temp** shows the camera's **board temperature** (checked: 22–23 °C at a cold start in a 21 °C room); from 45 °C it also appears in the LiveView top bar (orange from 50 °C, red from 60 °C). Canon protects itself regardless: a thermometer icon, then it stops recording. Prefs → **Temperature warning** (55 °C by default) shows HOT in the recording status above that |
| False colour | Overlay → False color → **Source: Preview (YUV) / RAW sensor** |
| Waveform | Overlay → Waveform → **Source: Preview (YUV) / RAW sensor** |
| Shutter angle | shown in the LiveView info bar |
| MLV playback | enable **both** `mlv_play` and `silent` in Modules; leave Silent Picture off. With RAW video on, PLAY opens ML's player (slow, but shows 10/12/14-bit); **disable `mlv_play`** to review the proxy MP4s in Canon's player instead |

In **Auto**, the WAV starts and stops with the raw clip and is filed as `DCIM/AUDIO/<clip>.WAV` —
`M09-1231.MLV` gets `DCIM/AUDIO/M09-1231.WAV`; manual takes are `W<day>-<hhmm>.WAV`. Costs
~0.19 MB/s and records no video, unlike the H.264 proxy. The **Safety** modes record the right
channel lower than the left as a backup for clipped peaks; `wav_dualgain.py` merges them.

### Syncing with a sound recordist (Tentacle Sync)

The scratch WAV can carry the same timecode as the recordist's files, and be lined up with your
video exactly, so his audio and your picture sync by timecode in Resolve or Premiere.

1. **On set:** a Tentacle on the camera, jammed from the recordist's, plugged into the mic jack
   with timecode on one channel (and, if you like, a mic passed through on the other).
   Movie → Scratch audio → **Input: External**, **Gain: Manual** at a low level — timecode is a
   loud square wave; keep its peaks well under CLIP on the meter.
2. **At offload:** `python extras/tools/scratch_sync.py <card>` writes `synced/<clip>.wav` for every
   clip — starting on the clip's first frame, the clip's length, and stamped with the first frame's
   timecode — plus a list of every clip's start timecode. It only reads the card.
3. **In Resolve:** import the MLV App exports, the synced WAVs and the recordist's files; sync the
   recordist's files by timecode. `--mov <export folder>` (needs ffmpeg) also writes `_tc.mov`
   copies of the exports carrying the synced scratch and the start timecode.

It needs clips recorded with v91 or later (each clip records when its WAV started). **Calibrate
once:** record a take with a sharp clap in shot, sync it, and measure how far the clap sound sits
from the clap frame (sound late = positive); pass that as `--latency-ms` from then on
([sync-test.md](sync-test.md) has the full calibration and clock test).

**Clock drift.** Each take starts from the Tentacle's timecode at frame 1, so the camera's clock
cannot drift from take to take; within a take, picture moves off the recordist's sound by the
camera's clock error times the take's length, more as the camera heats up. `scratch_sync.py`
lists each clip's `clock` (ppm against the Tentacle) and `drift` (frames by the last frame), from
the LTC at both ends; under a quarter frame is invisible. MLV Drive does the same and notes it in
the clip's folder.

**Without a timecode box, sync with a clap.** The WAV starts a moment before the first frame, so it
runs 0.4–1.6 s longer than the clip, at the front (longer with the H.264 proxy on). Some 10-bit and crop-mode takes in
earlier builds came out up to 2 s *shorter*; the v86 field round did not repeat it. Either way,
slate or clap at the start of a take and sync on that rather than lining up the file starts.

## Worth knowing before you shoot

**Set exposure before you roll, and read the raw waveform in stops.** Set to RAW, the waveform, histogram and false colour read the sensor at any bit depth. Below 14-bit, they switch to
the preview picture during a take, so check them before you press record. The histogram and waveform spread 12 stops evenly, so **their middle is not a mid-tone**: it is 6 stops under clipping. The yellow line marks middle grey: put the middle of your scene on it, and
expose as brightly as you can without clipping what matters.

| Raw histogram or waveform | Stops under clipping | Raw false colour | Plain Rec.709 in post | |
|---|---|---|---|---|
| 100% | 0 | magenta | 100% | clipped |
| 92% | 1 | orange to yellow | 71% | bright highlights |
| 83% | 2 | yellow to green | 49% | skin, bright subjects |
| 71–75% | 3–3.5 | green | 27–33% | middle grey |
| 58% | 5 | cyan | 13% | deep tones |
| 50% | 6 | cyan to light blue | 7% | near the bottom in post |

Grey is not a raw false colour. If you see it, false colour is on Preview (YUV), so set its Source to RAW.

**Set the ISO you need — don't underexpose at 100 and lift in the grade.** This sensor is strongly
ISO-variant: raising ISO costs only 0.14 EV of dynamic range per stop up to 3200, while shadow noise
improves 17×. Measured on this body, in video mode:

| ISO | dynamic range | |
|---|---|---|
| 100 | 11.15 EV | |
| 400 | 10.90 EV | |
| 800 | 10.86 EV | best value — 0.04 EV worse than 400, half the noise |
| 1600 | 10.58 EV | |
| 3200 | 10.23 EV | **practical ceiling** |
| 6400 | 9.41 EV | analog gain stops at 3200; this is a digital push |
| 25600 | 8.84 EV | |

**Stay on full stops.** Analog gain exists only at 100 / 200 / 400 / 800 / 1600 / 3200. Every third
(125, 250, 500…) is a full stop below plus a digital push baked irreversibly into the raw — ISO 250
measures as analog 200 + ⅜ stop.

Full method and figures are in the [development log](devlog.md).

**Peaking sparkle at high ISO:** set Threshold to 5–10 (not 40), Filter edges OFF, then Noise
rejection `Steady + Wide`.

**Card speed decides resolution.** A take runs until the card is full when its data rate stays
under the card's *slowest* writing, not its benchmark average. Raw MB/s at 23.976 fps (add ~3.8
for the H.264 proxy and scratch WAV):

| 23.976 fps | 14-bit | 12-bit | 10-bit |
|---|---|---|---|
| 1920×1080 | 87 MB/s | 74.6 | 62.2 |
| 1920×804 (2.39:1) | 64.8 | 55.5 | 46.3 |
| 2048×1080 (1.90:1 DCI) | 92.8 | 79.5 | 66.3 |
| 2048×856 (2.39:1) | 73.6 | 63.0 | 52.5 |

That table is uncompressed. **Lossless**, the default, needs far less, and how much depends on the scene. Some measured takes at 12-bit lossless:

| Format | Frame rate | MB/s |
|---|---|---|
| 2048×1152 | 23.976 | 32 |
| 3072×614 or 2136×894 (crop) | 29.97 | 34 |
| 1920×720 | 59.94 | 49 |
| 2048×856 | 59.94 | 58 |

Noise raises these: 1920×804 at ISO 6400 needed about 66 MB/s, against 42 to 45 in a clean scene. A card also slows as it fills: one 64 GB card wrote about 74 MB/s empty and 62 MB/s at 75% full. At 59.94p, frames above 1920×960 can fail, because the encoder runs out of time.

For the uncompressed table, crop mode runs at 29.97, so multiply by 1.25. A SanDisk Extreme PRO 64 GB writes ~83 MB/s new:
**2048×856 12-bit + proxy** (66.8 MB/s, ~16 min per card) runs continuously on it. The same card
after being filled once dropped to ~62 MB/s; there, use **1920×804 10-bit + proxy** (50 MB/s, ~21
min). Benchmark a card in a photo mode (Debug → Benchmarks): with RAW video on, the benchmark cannot
get its memory. The full ladder is in the [development log](devlog.md).

**10-bit or 12-bit?** 12-bit is lossless in practice. 10-bit costs about half a stop of shadow range
at ISO 100-400 (it shows as blotchy shadows when you lift them) and is hard to tell apart from ~ISO
800 up. Highlights and midtones are the same.

**Clips from before v62** carry a wrong black level on lit scenes (shadows crushed in MLV App). Run
`extras/tools/fix_mlv_black.py` (in the zip) on them, or set RAW black level to 2047 (512 at 12-bit, 128 at 10-bit).

## Not possible on this body (yet)

FPS override, 24p in crop mode (four rounds of experiments, always 29.97),
expo override, auto-ETTR, video dual ISO in 1080p, 4K / custom crop windows, `mlv_snd`, H.264
bitrate control, a different audio source per channel, crop mode or a bit-depth switch with the
lens on AF, a recorded-area guide in crop mode, separate DRIVE / metering / AF-point buttons.

Photo dual ISO works. Face-tracking AF works natively. See the [roadmap](roadmap.md).

## What's in the zip

| | |
|---|---|
| `autoexec.bin`, `ML/` | Magic Lantern itself — **copy these to the card** |
| `ML-SETUP.FIR` | the installer, needed once per camera (1.1.1 zip only) — **copy to the card for a first install** |
| `README.txt` | install steps |
| `SHA256SUMS.txt` | checksums of the camera files |
| `extras/user-guide.md` | this guide |
| `extras/tools/` | `cardcheck.py` (checks every clip on a card), `gyro_export.py` (writes Gyroflow logs from clips recorded with Gyro log on), `scratch_sync.py` (lines scratch WAVs up with their clips and stamps them with Tentacle timecode), `wav_dualgain.py` (merges a Safety-mode WAV into a 32-bit float file), `fix_mlv_black.py` (repairs pre-v62 black levels) |
| `extras/testing/` | the field test procedure |
| `extras/developer/` | development log and roadmap |

Nothing under `extras` goes on the card.

## Reporting a problem

Send the `CRASH*.LOG` / `ASSERT*.LOG` files from the card root (they name the file and line), the
contents of `ML/LOGS/`, and a `cardcheck.py` report if clips are involved.

For developers: the `d7probe` module (**6D2 developer tools** in the Modules menu, off by
default) gathers the port's research tools under Debug → 6D2 developer tools. **Recording trace**
there logs each take's record path to `ML/LOGS/RECDBG.LOG`, flushed per line so it survives a
battery pull; **State logger** records button events and the camera's MPU messages. The FPS and SD
clock experiments in it write camera registers: research use only, with a spare card.
